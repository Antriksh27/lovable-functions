# Lovable Functions

This repository contains custom backend functions for my Lovable CRM project.

## Setup
1. Install dependencies:
   ```bash
   npm install
